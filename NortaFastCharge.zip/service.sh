#!/system/bin/sh
# ./service.sh

# NortaFastCharge - Service
# Author: Norta

MODDIR="/data/adb/modules/nortaFastCharge"
sh "$MODDIR/system/etc/nortaCore/nortaCore.sh"
