#!/system/bin/sh
# ./system/etc/nortaCore/nortaCore.sh

# NortaFastCharge - Core Engine
# Author: Norta
# Device: Poco X3 Pro (vayu) - Snapdragon 860

writeNode() {
    if [ -f "$2" ]; then
        chmod 0666 "$2"
        echo "$1" > "$2"
        chmod 0444 "$2"
    fi
}

applyCurrent() {
    NODES=$(ls /sys/class/power_supply/*/$1 2>/dev/null)
    for NODE in $NODES; do
        writeNode $CURRENT_MA $NODE
    done
}

CHARGE_LEVEL=<CHARGE_LEVEL>
CURRENT_MA=$((CHARGE_LEVEL * 1000))
CURRENT_MAX_MA=$(((CHARGE_LEVEL + 1000) * 1000))

while true; do
    writeNode '1' /sys/class/power_supply/usb/fastcharge_mode
    writeNode '1' /sys/class/power_supply/bms/fastcharge_mode
    writeNode '0' /sys/class/qcom-battery/restrict_chg
    writeNode $CURRENT_MAX_MA /sys/class/qcom-battery/restrict_cur
    writeNode '0' /sys/class/power_supply/battery/input_current_limited
    applyCurrent current_max
    applyCurrent hw_current_max
    applyCurrent ctm_current_max
    applyCurrent constant_charge_current_max
    sleep 5
done
