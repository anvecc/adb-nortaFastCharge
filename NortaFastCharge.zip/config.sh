#!/system/bin/sh
# ./config.sh

# NortaFastCharge - Config
# Value: 2670, 3000, 3500, 4000, 4500, 5000, 5500

CHARGE_LEVEL=5000
