#!/system/bin/sh
# ./post-fs-data.sh

# NortaFastCharge - Post FS Data
# Author: Norta

MODDIR="${0%/*}"

# Set permission 
chmod 0777 "$MODDIR/system/etc/nortaCore/nortaCore.sh"
chmod 0777 "$MODDIR/service.sh"
