#!/system/bin/sh
# ./customize.sh

# NortaFastCharge - Installer
# Author: Norta

SKIPUNZIP=1

unzip -o "$ZIPFILE" 'system/*' -d "$MODPATH" >&2
unzip -o "$ZIPFILE" 'config.sh' -d "$MODPATH" >&2
unzip -o "$ZIPFILE" 'service.sh' -d "$MODPATH" >&2
unzip -o "$ZIPFILE" 'module.prop' -d "$MODPATH" >&2
unzip -o "$ZIPFILE" 'post-fs-data.sh' -d "$MODPATH" >&2

CORE="$MODPATH/system/etc/nortaCore/nortaCore.sh"

. "$MODPATH/config.sh"

ui_print " "
ui_print "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
ui_print "      🌩️ NortaFastCharge 🌩️     "
ui_print "    Poco X3 Pro (vayu) Edition   "
ui_print "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
ui_print " "
ui_print "  ⚡ Charge Level : ${CHARGE_LEVEL} mA"
ui_print " "

sed -i "s/<CHARGE_LEVEL>/${CHARGE_LEVEL}/g" "$CORE"

set_perm_recursive "$MODPATH" 0 0 0755 0644
set_perm "$MODPATH/service.sh" 0 0 0777
set_perm "$CORE" 0 0 0777

ui_print "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
ui_print "  ✅ NortaFastCharge Setup Done! "
ui_print " "
ui_print "  Report bug : @iamnorta           "
ui_print "  Channel    : t.me/iamnorta      "
ui_print "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
ui_print " "
